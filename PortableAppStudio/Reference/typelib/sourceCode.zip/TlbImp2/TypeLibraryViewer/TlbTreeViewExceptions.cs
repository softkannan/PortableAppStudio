﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TypeLibraryTreeView
{
    public class NotFormDaemonException : Exception
    {
    }
}
