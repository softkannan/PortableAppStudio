﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TlbImpRuleEngine
{
    public interface IGetTypeLibElementCommonInfo
    {
        string Name
        {
            get;
        }

        string Type
        {
            get;
        }
    }
}
