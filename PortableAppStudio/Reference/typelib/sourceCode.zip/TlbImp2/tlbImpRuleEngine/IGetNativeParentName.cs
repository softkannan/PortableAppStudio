﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TlbImpRuleEngine
{
    public interface IGetNativeParentName
    {
        string GetNativeParentName();
    }
}
