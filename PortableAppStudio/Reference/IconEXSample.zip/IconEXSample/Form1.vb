Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents dlgOpen As System.Windows.Forms.OpenFileDialog
    Friend WithEvents btnOpen As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btnGo As System.Windows.Forms.Button
    Friend WithEvents dlgSave As System.Windows.Forms.SaveFileDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.dlgOpen = New System.Windows.Forms.OpenFileDialog
        Me.btnOpen = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.btnGo = New System.Windows.Forms.Button
        Me.dlgSave = New System.Windows.Forms.SaveFileDialog
        Me.SuspendLayout()
        '
        'dlgOpen
        '
        Me.dlgOpen.Filter = "BMP Files|*.bmp"
        '
        'btnOpen
        '
        Me.btnOpen.Location = New System.Drawing.Point(16, 8)
        Me.btnOpen.Name = "btnOpen"
        Me.btnOpen.Size = New System.Drawing.Size(56, 32)
        Me.btnOpen.TabIndex = 0
        Me.btnOpen.Text = "Open"
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Location = New System.Drawing.Point(80, 8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(32, 32)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'btnGo
        '
        Me.btnGo.Location = New System.Drawing.Point(16, 56)
        Me.btnGo.Name = "btnGo"
        Me.btnGo.TabIndex = 2
        Me.btnGo.Text = "Create"
        '
        'dlgSave
        '
        Me.dlgSave.DefaultExt = "ico"
        Me.dlgSave.FileName = "myicon"
        Me.dlgSave.Filter = "ICO Files|*.ico"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(128, 101)
        Me.Controls.Add(Me.btnGo)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnOpen)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpen.Click
        If dlgOpen.ShowDialog() = DialogResult.OK Then
            'assumes, for sample, that bitmap is already at 32 px by 32 px
            Dim MyBMP As New Bitmap(dlgOpen.FileName)
            PictureBox1.Image = MyBMP
        End If
    End Sub

    Private Sub btnGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGo.Click
        If dlgSave.ShowDialog = DialogResult.OK Then
            'creates icon file so we can edit it with IconEX.dll
            Dim MyBMP As New Bitmap(32, 32, System.Drawing.Imaging.PixelFormat.Format24bppRgb)
            Dim MyIcon As Icon = Icon.FromHandle(MyBMP.GetHicon)
            Dim st As System.IO.Stream = New System.IO.FileStream _
                              (dlgSave.FileName, IO.FileMode.Create)
            Dim wr As New System.IO.BinaryWriter(st)
            MyIcon.Save(st)
            MyBMP.Dispose()
            wr.Close()
            '-- END icon creation --

            'Opens icon for editing with IconEX
            Dim Iconex As New vbAccelerator.Components.Win32.IconEx(dlgSave.FileName)
            'Removes original icon image that we created above
            Iconex.Items.RemoveAt(0)
            'Creates a new IconDeviceImage, to store the new icon image
            Dim IconDeviceImage As New vbAccelerator.Components.Win32.IconDeviceImage _
                                             (New Size(32, 32), ColorDepth.Depth32Bit)
            'gets bitmap of (assumed) 32 x 32 bitmap in picturebox, sets it to IconImage
            IconDeviceImage.IconImage = New Bitmap(PictureBox1.Image)
            'adds icondevicimage to the icon file
            Iconex.Items.Add(IconDeviceImage)
            'saves icon 
            Iconex.Save(dlgSave.FileName)
            MessageBox.Show("Icon Created!")
        End If

    End Sub

    Private Sub dlgOpen_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles dlgOpen.FileOk

    End Sub
End Class
