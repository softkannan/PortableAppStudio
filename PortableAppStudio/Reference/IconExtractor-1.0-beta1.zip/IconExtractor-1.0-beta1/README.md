# IconExtractor

Icon Extractor Library for .NET

Working on a revised version of my CodeProject article:

http://www.codeproject.com/Articles/26824/Extract-icons-from-EXE-or-DLL-files
