﻿namespace MadMilkman.Ini
{
    internal interface IItemNameVerifier { bool VerifyItemName(string name); }
}
