﻿namespace MadMilkman.Ini
{
    internal enum IniCommentType
    {
        Leading = 0,
        Trailing
    }
}
