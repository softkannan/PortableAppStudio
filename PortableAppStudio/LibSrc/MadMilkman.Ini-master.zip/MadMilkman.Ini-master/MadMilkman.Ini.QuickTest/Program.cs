﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using MadMilkman.Ini;

namespace MadMilkman.Ini.QuickTest
{
    class Program
    {
        static string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

        static void Main(string[] args)
        {

        }
    }
}
